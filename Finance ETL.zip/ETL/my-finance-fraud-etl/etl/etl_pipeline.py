import os, yaml
from datetime import datetime
from pyspark.sql import SparkSession, Window
from pyspark.sql.functions import (
    col, to_timestamp, lag, when, lit, unix_timestamp, coalesce,
    sum as ssum, avg as savg, stddev as sstd, month, year, date_trunc, to_date, dayofweek, hour
)
from pyspark.sql.types import StructType, StructField, StringType, DoubleType, TimestampType
from sklearn.ensemble import IsolationForest
import pandas as pd

with open("config/config.yaml", "r") as f:
    CFG = yaml.safe_load(f)

CSV_PATH = CFG["data"]["transactions_csv"]

PG_HOST = os.getenv(CFG["postgres"]["host_env"], "db")
PG_PORT = os.getenv(CFG["postgres"]["port_env"], "5432")
PG_DB   = os.getenv(CFG["postgres"]["db_env"], "etl_db")
PG_USER = os.getenv(CFG["postgres"]["user_env"], "etl_user")
PG_PASS = os.getenv(CFG["postgres"]["pass_env"], "etl_password")
PG_SCHEMA = CFG["postgres"]["schema"]
TBL = CFG["postgres"]["tables"]

JDBC_URL = f"jdbc:postgresql://{PG_HOST}:{PG_PORT}/{PG_DB}"
JDBC_PROPS = {"user": PG_USER, "password": PG_PASS, "driver": "org.postgresql.Driver"}

spark = (
    SparkSession.builder
    .appName(CFG["spark"]["app_name"])
    .master(CFG["spark"]["master"])
    .config("spark.jars.packages", CFG["spark"]["jars_packages"])
    .getOrCreate()
)
spark.sparkContext.setLogLevel("WARN")

# Ensure CSV exists (generate if missing)
if not os.path.exists(CSV_PATH):
    print("[INFO] Generating demo transactions...")
    import generate_data as gen  # will write to CSV_PATH
    # The generator writes on import run if used as script; call directly otherwise
    import importlib
    importlib.reload(gen)

schema = StructType([
    StructField("transaction_id", StringType(), False),
    StructField("customer_id", StringType(), True),
    StructField("transaction_date", StringType(), True),
    StructField("amount", DoubleType(), True),
    StructField("transaction_type", StringType(), True),
    StructField("merchant", StringType(), True),
    StructField("category", StringType(), True),
    StructField("city", StringType(), True),
])

df = spark.read.option("header", True).schema(schema).csv(CSV_PATH)

df = df.withColumn("transaction_ts", to_timestamp("transaction_date")) \
       .drop("transaction_date")

# Basic cleaning: fill amount <= 0 with small positive, normalize txn_type
df = df.withColumn("amount", when((col("amount").isNull()) | (col("amount") <= 0), lit(1.0)).otherwise(col("amount"))) \
       .withColumn("txn_type", when(col("transaction_type").isin("DEBIT","CREDIT"), col("transaction_type")).otherwise(lit("DEBIT")))

# Feature engineering for rules & ML
w_cust = Window.partitionBy("customer_id").orderBy(col("transaction_ts").cast("long"))

df = df.withColumn("prev_ts", lag("transaction_ts").over(w_cust)) \
       .withColumn("prev_city", lag("city").over(w_cust)) \
       .withColumn("time_diff_s", unix_timestamp("transaction_ts") - unix_timestamp("prev_ts")) \
       .withColumn("city_change", when((col("prev_city").isNull()) | (col("city") == col("prev_city")), lit(0)).otherwise(lit(1))) \
       .withColumn("hour_of_day", hour(col("transaction_ts"))) \
       .withColumn("day_of_week", dayofweek(col("transaction_ts")))

# Per-customer amount stats
w_cust_rows = Window.partitionBy("customer_id").rowsBetween(Window.unboundedPreceding, Window.unboundedFollowing)
df = df.withColumn("amt_mean_cust", savg("amount").over(w_cust_rows)) \
       .withColumn("amt_std_cust", sstd("amount").over(w_cust_rows))

df = df.withColumn("amt_z", (col("amount") - col("amt_mean_cust")) / when(col("amt_std_cust") > 0, col("amt_std_cust")).otherwise(lit(1.0)))

# Rare merchant for this customer (approx: count per customer-merchant)
w_c_m = Window.partitionBy("customer_id", "merchant").rowsBetween(Window.unboundedPreceding, Window.unboundedFollowing)
df = df.withColumn("cust_merchant_count", ssum(lit(1)).over(w_c_m)) \
       .withColumn("rare_merchant", when(col("cust_merchant_count") <= 1, lit(1)).otherwise(lit(0)))

# ----- Rule-based fraud flags -----
high_amount_flag = (col("amount") > lit(5000))
rapid_fire_flag  = (col("time_diff_s").isNotNull()) & (col("time_diff_s") >= 0) & (col("time_diff_s") < lit(60))
geo_jump_flag    = (col("city_change") == 1) & (col("time_diff_s").isNotNull()) & (col("time_diff_s") >= 0) & (col("time_diff_s") < lit(3600))

df = df.withColumn("rules_flag", when(high_amount_flag | rapid_fire_flag | geo_jump_flag, lit(1)).otherwise(lit(0)))

def reason_expr():
    return when(high_amount_flag, lit("HIGH_AMOUNT")) \
           .when(rapid_fire_flag, lit("RAPID_FIRE")) \
           .when(geo_jump_flag, lit("GEO_JUMP")) \
           .otherwise(lit(None))

df = df.withColumn("rules_reason", reason_expr())

# ----- ML-based anomaly detection (IsolationForest with sklearn) -----
# Prepare feature set in pandas (dataset is small)
features_cols = ["amount", "time_diff_s", "hour_of_day", "day_of_week", "city_change", "rare_merchant", "amt_z"]
sel = df.select("transaction_id", *features_cols)
p = sel.fillna({"time_diff_s": 999999, "amt_z": 0}).toPandas()

# Replace infinities if any
import numpy as np
p = p.replace([np.inf, -np.inf], 0)

X = p[features_cols].values
iso = IsolationForest(
    n_estimators=200,
    contamination=0.02,  # ~2% anomalies
    random_state=42
).fit(X)

# Decision function: higher = less anomalous. Convert to anomaly_score where higher = more anomalous.
scores = iso.score_samples(X)  # lower = more anomalous
anomaly = iso.predict(X)       # -1 = anomaly, 1 = normal
p["ml_score"] = (-scores)      # higher means more anomalous
p["ml_anomaly"] = (anomaly == -1).astype(int)

# Join back to Spark
pdf = spark.createDataFrame(p[["transaction_id", "ml_score", "ml_anomaly"]])
df = df.join(pdf, on="transaction_id", how="left")

# ----- Monthly summary -----
month_key = to_date(date_trunc("month", col("transaction_ts")))
monthly = df.withColumn("month_key", month_key) \
            .withColumn("income", when(col("txn_type")=="CREDIT", col("amount")).otherwise(lit(0.0))) \
            .withColumn("expenses", when(col("txn_type")=="DEBIT", col("amount")).otherwise(lit(0.0))) \
            .groupBy("month_key") \
            .agg(ssum("income").alias("income"),
                 ssum("expenses").alias("expenses")) \
            .withColumn("net_balance", col("income") - col("expenses"))

# ----- Write to Postgres -----
def write_table(df_, name, mode="overwrite"):
    print(f"[LOAD] Writing table {name} ({mode})")
    (df_.write.format("jdbc")
        .option("url", JDBC_URL)
        .option("dbtable", f"{PG_SCHEMA}.{name}")
        .options(**JDBC_PROPS)
        .mode(mode)
        .save())

# Minimal bootstrap: create schema via writing
transactions_cols = ["transaction_id","customer_id","transaction_ts","amount","txn_type","merchant","category","city"]
write_table(df.select(*transactions_cols), TBL["transactions"], mode="overwrite")
write_table(monthly.select("month_key","income","expenses","net_balance"), TBL["monthly_summary"], mode="overwrite")
write_table(df.select("transaction_id","rules_flag","rules_reason","ml_score","ml_anomaly"), TBL["fraud_flags"], mode="overwrite")

print("[DONE] ETL completed at", datetime.now().isoformat())
spark.stop()
