import pathlib, random, string
from datetime import datetime, timedelta
import pandas as pd

OUT = pathlib.Path("data/transactions.csv")
OUT.parent.mkdir(parents=True, exist_ok=True)

random.seed(42)

customers = [f"C{1000+i}" for i in range(50)]
merchants = ["MegaMart", "QuickBuy", "CityCafe", "FreshFoods", "ElectroMax", "TravelNow", "FuelPlus", "BookHive"]
categories = {
    "MegaMart":"shopping", "QuickBuy":"shopping", "CityCafe":"food", "FreshFoods":"groceries",
    "ElectroMax":"electronics", "TravelNow":"travel", "FuelPlus":"fuel", "BookHive":"books"
}
cities = ["Kathmandu","Pokhara","Lalitpur","Delhi","Mumbai","Bangalore","London","New York"]

start = datetime.now() - timedelta(days=120)
rows = []
tid = 1
for cust in customers:
    t = start + timedelta(days=random.randint(0, 5))
    for _ in range(random.randint(10, 30)):
        m = random.choice(merchants)
        cat = categories[m]
        amt = abs(random.gauss(50, 30)) + random.choice([0,10,20])
        if random.random() < 0.25 and cat in ("electronics","travel"):
            amt += random.uniform(100, 400)

        city = random.choice(cities[:3]) if random.random() < 0.7 else random.choice(cities)
        t += timedelta(days=random.randint(0, 5), minutes=random.randint(5, 120))
        txn_type = "DEBIT" if random.random() < 0.8 else "CREDIT"

        rows.append({
            "transaction_id": f"T{tid:06d}",
            "customer_id": cust,
            "transaction_date": t.replace(microsecond=0).isoformat(sep=" "),
            "amount": round(amt if txn_type=="DEBIT" else amt, 2),
            "transaction_type": txn_type,
            "merchant": m,
            "category": cat,
            "city": city
        })
        tid += 1

# Inject fraud-like patterns
# 1) High-value single shots
for _ in range(15):
    cust = random.choice(customers)
    m = random.choice(merchants)
    cat = categories[m]
    city = random.choice(cities)
    t = start + timedelta(days=random.randint(10,110), minutes=random.randint(0, 60*24))
    rows.append({
        "transaction_id": f"T{tid:06d}",
        "customer_id": cust,
        "transaction_date": t.replace(microsecond=0).isoformat(sep=" "),
        "amount": round(random.uniform(7000, 20000), 2),
        "transaction_type": "DEBIT",
        "merchant": m,
        "category": cat,
        "city": city
    })
    tid += 1

# 2) Rapid-fire duplicates
for _ in range(10):
    cust = random.choice(customers)
    base_time = start + timedelta(days=random.randint(20,100), hours=random.randint(0,23))
    city = random.choice(cities[:3])
    for j in range(3):  # 3 in a minute
        rows.append({
            "transaction_id": f"T{tid:06d}",
            "customer_id": cust,
            "transaction_date": (base_time + timedelta(seconds=15*j)).replace(microsecond=0).isoformat(sep=" "),
            "amount": round(random.uniform(200, 500), 2),
            "transaction_type": "DEBIT",
            "merchant": "QuickBuy",
            "category": "shopping",
            "city": city
        })
        tid += 1

# 3) Geo jumps
for _ in range(10):
    cust = random.choice(customers)
    t1 = start + timedelta(days=random.randint(30,90), hours=9)
    city1 = "Kathmandu"
    city2 = "London"
    rows.append({
        "transaction_id": f"T{tid:06d}",
            "customer_id": cust,
            "transaction_date": t1.replace(microsecond=0).isoformat(sep=" "),
            "amount": 120.00,
            "transaction_type": "DEBIT",
            "merchant": "CityCafe",
            "category": "food",
            "city": city1
    })
    tid += 1
    rows.append({
        "transaction_id": f"T{tid:06d}",
            "customer_id": cust,
            "transaction_date": (t1 + timedelta(minutes=45)).replace(microsecond=0).isoformat(sep=" "),
            "amount": 85.00,
            "transaction_type": "DEBIT",
            "merchant": "CityCafe",
            "category": "food",
            "city": city2
    })
    tid += 1

df = pd.DataFrame(rows).sort_values("transaction_date")
OUT.write_text(df.to_csv(index=False))
print(f"Wrote {OUT.resolve()} with {len(df)} rows")
