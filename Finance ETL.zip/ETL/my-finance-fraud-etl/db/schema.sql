CREATE TABLE IF NOT EXISTS transactions (
  transaction_id TEXT PRIMARY KEY,
  customer_id    TEXT,
  transaction_ts TIMESTAMP,
  amount         NUMERIC,
  txn_type       TEXT,
  merchant       TEXT,
  category       TEXT,
  city           TEXT
);

CREATE TABLE IF NOT EXISTS monthly_summary (
  month_key      DATE PRIMARY KEY,
  income         NUMERIC,
  expenses       NUMERIC,
  net_balance    NUMERIC
);

CREATE TABLE IF NOT EXISTS fraud_flags (
  transaction_id TEXT PRIMARY KEY,
  rules_flag     INT,
  rules_reason   TEXT,
  ml_score       DOUBLE PRECISION,
  ml_anomaly     INT
);

CREATE INDEX IF NOT EXISTS idx_txn_customer ON transactions(customer_id);
CREATE INDEX IF NOT EXISTS idx_txn_ts ON transactions(transaction_ts);
