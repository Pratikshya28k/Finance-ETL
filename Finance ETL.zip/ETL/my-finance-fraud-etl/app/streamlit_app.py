import os, yaml, psycopg2, pandas as pd
import streamlit as st
import plotly.express as px

# Config
with open("config/config.yaml", "r") as f:
    CFG = yaml.safe_load(f)

PG = CFG["postgres"]
CONN_KW = dict(
    host=os.getenv(PG["host_env"], "localhost"),
    port=int(os.getenv(PG["port_env"], "5432")),
    dbname=os.getenv(PG["db_env"], "etl_db"),
    user=os.getenv(PG["user_env"], "etl_user"),
    password=os.getenv(PG["pass_env"], "etl_password")
)

st.set_page_config(page_title="Finance Dashboard with Fraud Insights", layout="wide")
st.title("💸 Finance Dashboard + 🚨 Fraud Insights")

@st.cache_data(ttl=300)
def load_df(sql: str) -> pd.DataFrame:
    with psycopg2.connect(**CONN_KW) as conn:
        return pd.read_sql(sql, conn)

# KPIs from monthly summary
ms = load_df("SELECT * FROM public.monthly_summary ORDER BY month_key;")
total_income = ms["income"].sum() if not ms.empty else 0
total_expenses = ms["expenses"].sum() if not ms.empty else 0
net_balance = total_income - total_expenses

fraud = load_df("SELECT * FROM public.fraud_flags;")
num_flags = int(fraud["rules_flag"].sum() + fraud["ml_anomaly"].sum()) if not fraud.empty else 0

c1,c2,c3,c4 = st.columns(4)
c1.metric("Total Income", f"${total_income:,.2f}")
c2.metric("Total Expenses", f"${total_expenses:,.2f}")
c3.metric("Net Balance", f"${net_balance:,.2f}")
c4.metric("Fraud Flags (rules+ML)", f"{num_flags:,}")

st.divider()

# Charts
left, right = st.columns(2)

with left:
    st.subheader("Balance Over Time")
    if not ms.empty:
        fig = px.line(ms, x="month_key", y=["income","expenses","net_balance"], title="Monthly Income / Expenses / Net")
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("No monthly data yet. Run the ETL.")

with right:
    st.subheader("Fraud by Reason (Rules)")
    reasons = load_df("""
        SELECT rules_reason, COUNT(*) AS cnt
        FROM public.fraud_flags
        WHERE rules_flag = 1 AND rules_reason IS NOT NULL
        GROUP BY rules_reason
        ORDER BY cnt DESC;
    """)
    if reasons.empty:
        st.info("No rule-based fraud flags yet.")
    else:
        fig2 = px.bar(reasons, x="rules_reason", y="cnt", title="Rule-based Fraud Flags by Reason")
        st.plotly_chart(fig2, use_container_width=True)

st.subheader("Suspicious Transactions")
threshold = st.slider("ML anomaly score threshold (higher = more anomalous)", min_value=0.0, max_value=1.5, value=0.35, step=0.01)
sql = f"""
SELECT t.transaction_id, t.customer_id, t.transaction_ts, t.amount, t.txn_type, t.merchant, t.category, t.city,
       f.rules_flag, f.rules_reason, f.ml_score, f.ml_anomaly
FROM public.transactions t
JOIN public.fraud_flags f USING (transaction_id)
WHERE (f.rules_flag = 1) OR (f.ml_anomaly = 1) OR (f.ml_score >= {threshold})
ORDER BY f.ml_score DESC
LIMIT 500;
"""
sus = load_df(sql)
st.dataframe(sus, use_container_width=True)

if not sus.empty:
    fig3 = px.histogram(sus, x="ml_score", nbins=30, title="Distribution of ML Anomaly Scores (shown rows)")
    st.plotly_chart(fig3, use_container_width=True)
