# Finance ETL + Fraud Detection (PySpark → Postgres → Streamlit)

This is a **ready-to-run** project that loads financial transactions, detects fraud, and shows an interactive dashboard.

## 🟢 Easiest way to run (Docker)
1. Install **Docker Desktop** and open it.
2. Open a terminal **inside this folder**.
3. Start services:
   ```bash
   docker compose up -d
   ```
4. Run the ETL (loads data + fraud insights into Postgres):
   ```bash
   docker compose run --rm etl
   ```
5. Open the dashboard:
   - http://localhost:8501

### What you get
- **ETL**: PySpark pipeline → PostgreSQL (transactions, summaries, fraud flags)
- **Fraud detection**: Rule-based flags + **IsolationForest** (advanced ML)
- **Dashboard**: KPIs, charts, and a fraud insights page

> Postgres & Streamlit run in Docker; Spark job runs in a throwaway container when you execute the ETL command.

---

## 📂 Project structure
```
my-finance-fraud-etl/
├── app/
│   └── streamlit_app.py
├── config/
│   └── config.yaml
├── data/
│   └── transactions.csv
├── db/
│   └── schema.sql
├── docker/
│   └── Dockerfile
├── etl/
│   ├── generate_data.py
│   └── etl_pipeline.py
├── docker-compose.yml
├── requirements.txt
└── README.md
```

---

## 🔧 Configuration
- Change paths & table names: `config/config.yaml`
- Credentials live in the `.env` created by compose (defaults are fine for local run)

---

## ❓ Troubleshooting
- **Docker not running** → open Docker Desktop and retry.
- **Port in use** → stop other apps using 5432/8501 or change ports in `docker-compose.yml`.
- **ETL driver error** → re-run the ETL; it auto-downloads the Postgres JDBC driver.

---

## 🏆 Ideas to go further
- Schedule the ETL with Airflow (Docker)
- Add unit tests for transformation logic
- Add model monitoring for anomaly rates
